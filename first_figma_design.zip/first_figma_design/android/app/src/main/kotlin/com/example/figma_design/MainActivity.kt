package com.example.figma_design

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
